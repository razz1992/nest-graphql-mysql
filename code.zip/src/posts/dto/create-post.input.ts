import {  Field,  InputType,  Int,} from '@nestjs/graphql';
import {  IsNotEmpty,} from 'class-validator';

@InputType()
export class CreatePostInput {

  @Field()
  @IsNotEmpty()
  title: string;

  @Field()
  @IsNotEmpty()
  content: string;

  @Field(() => Int)
  userId: number;
}